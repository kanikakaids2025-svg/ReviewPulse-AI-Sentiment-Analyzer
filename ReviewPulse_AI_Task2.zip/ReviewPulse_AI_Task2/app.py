import streamlit as st
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

st.set_page_config(page_title="ReviewPulse AI", page_icon="💬", layout="centered")

@st.cache_resource
def load_model():
    # VADER is a pretrained rule/lexicon-based sentiment analysis model.
    return SentimentIntensityAnalyzer()

analyzer = load_model()

st.title("💬 ReviewPulse AI")
st.subheader("AI-Powered Product Review Sentiment Analyzer")
st.write(
    "Enter an English product review below. The VADER sentiment model "
    "will classify it as Positive, Negative, or Neutral."
)

review = st.text_area(
    "Product review",
    placeholder="Example: The product is excellent and works perfectly!",
    height=140
)

if st.button("Analyze Sentiment", type="primary", use_container_width=True):
    if not review.strip():
        st.warning("Please enter a review before analyzing.")
    else:
        scores = analyzer.polarity_scores(review)
        compound = scores["compound"]

        if compound >= 0.05:
            label = "Positive 😊"
        elif compound <= -0.05:
            label = "Negative 😞"
        else:
            label = "Neutral 😐"

        st.markdown("### Prediction")
        st.success(label) if compound >= 0.05 else (
            st.error(label) if compound <= -0.05 else st.info(label)
        )

        c1, c2, c3 = st.columns(3)
        c1.metric("Positive score", f'{scores["pos"]:.2f}')
        c2.metric("Neutral score", f'{scores["neu"]:.2f}')
        c3.metric("Negative score", f'{scores["neg"]:.2f}')

        st.caption(f'Compound score: {compound:.3f} (range: -1 to +1)')
        with st.expander("How to read this result"):
            st.write(
                "The compound score summarizes the overall sentiment. "
                "Scores ≥ 0.05 are Positive, scores ≤ -0.05 are Negative, "
                "and scores between them are Neutral. This is a prototype; "
                "sarcasm and context-specific meanings may be misclassified."
            )

st.divider()
st.markdown("#### Try an example")
examples = [
    "This product is amazing. I love it!",
    "Terrible quality. It stopped working after one day.",
    "The package arrived today. The box is blue."
]
for example in examples:
    st.code(example, language=None)

st.caption("Prototype for Task 2: Model or API Integration | Model library: VADER Sentiment")
